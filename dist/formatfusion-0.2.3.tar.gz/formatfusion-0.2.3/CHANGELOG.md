## 0.2.3 (2024-02-06)

### Fix

- **setup.py,-FormatFusion/cli.py**: fix issue

## 0.2.2 (2024-02-06)

### Fix

- fix cli

## 0.2.1 (2024-02-06)

### Fix

- **cli.py**: rename cli.py into main.py

## 0.2.0 (2024-02-06)

### Feat

- **FormatFusion/cli.py**: add command line interface

## 0.1.0 (2024-02-06)

### Feat

- add csv data conversion

### Refactor

- **FormatFusion/**: fix issue #5
- change project name

## 1.5.0 (2023-12-18)

### Feat

- **yamlify/reader/reader.py**: add io functions
- **yamlify/reader/reader.py**: add io functions

## 1.4.0 (2023-12-15)

### Feat

- xml converter data
- **json_to_yaml.py**: add some more function

### Refactor

- change function and add new function
- refactor code structure
- fix configure

## 1.0.0 (2023-11-15)

### Feat

- **test.py**: add automatic testing

### Fix

- **test.py,-yaml_to_json.py**: fix minor issue

### Perf

- improve package functional
